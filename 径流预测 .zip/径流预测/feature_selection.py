import pandas as pd
from sklearn.feature_selection import mutual_info_regression
from add_next_prcp import addNextPrcpAndDischarge

def pearson(data, feature_num):
    data = data[data.columns[1:]]
    corr_matrix = data.corr(method='pearson')
    corr_with_target = corr_matrix['Discharge_next'].drop('Discharge_next')
    top_features = corr_with_target.abs().sort_values(ascending=False).head(feature_num).index
    return top_features

def mutualInformation(data, feature_num):
    data = data[data.columns[1:]]
    mi = mutual_info_regression(data.drop(columns='Discharge_next'), data['Discharge_next'])
    mi_series = pd.Series(mi, index=data.columns[1:])
    top_features = mi_series.sort_values(ascending=False).head(feature_num).index
    return top_features

if __name__ == "__main__":
    data = pd.read_csv('01169000.csv')
    data = addNextPrcpAndDischarge(data, 5)
    # selected_feature = pearson(data, 5, 20)
    selected_feature = mutualInformation(data, 5, 20)
    print(selected_feature)
