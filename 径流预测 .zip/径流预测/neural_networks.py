import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
from add_next_prcp import addNextPrcpAndDischarge
from feature_normalization import minMaxNorm, zSocre
from feature_selection import pearson, mutualInformation
from utils import *
import warnings
from sklearn.exceptions import ConvergenceWarning

# 过滤掉 ConvergenceWarning 类型的警告
warnings.filterwarnings("ignore", category=ConvergenceWarning)


def neural_networks(data_name, feature_selection, feature_normalization):

    time = 7
    feature_num = 30

    df = pd.read_csv(f'{data_name}.csv')
    data = addNextPrcpAndDischarge(df, time)
    train_data = data.where(data['Date'] <= '2003-12-31').dropna()
    test_data = data.where(data['Date'] > '2003-12-31').dropna()
    train_norm_data, test_norm_data,_ = selectAndNorm(train_data, test_data, feature_selection, feature_normalization, feature_num)

    x_train, y_train = create_dataset(train_data, train_norm_data, time, 5)
    x_test, y_test = create_dataset(test_data, test_norm_data, time, 5)

    mlp = MLPRegressor(max_iter=100, random_state=0)

    # 使用 GridSearchCV 进行超参数搜索
    grid_search = GridSearchCV(estimator=mlp, param_grid=param_grid, scoring='r2', cv=5)
    grid_search.fit(x_train, y_train)

    # 输出最佳超参数和对应的性能
    print(f"\n\n {data_name}_{feature_selection.__name__}_{feature_normalization.__name__}最佳超参数：", grid_search.best_params_)

    # 使用最佳模型进行预测
    best_model = grid_search.best_estimator_
    y_pred = best_model.predict(x_test)


    for i in range(5):
        mae = mean_absolute_error(y_test[:,i], y_pred[:,i])
        r2 = r2_score(y_test[:,i], y_pred[:,i])
        variance = np.var(y_test[:, i])
        smse = mean_absolute_error(y_test[:, i],y_pred[:, i]) / variance if variance != 0 else np.nan # 计算SMSE，避免除零错误
        print(f'{data_name}_{feature_selection.__name__}_{feature_normalization.__name__} Day {i + 1}  R²: {r2}, MAE: {mae}, SMSE: {smse}')

    x = [i for i in range(len(y_pred))]
    plt.figure(figsize=(10, 6))
    for i in range(5):
        plt.subplot(3, 2, i+1)
        plt.plot(x, y_test[:, i], color='blue', label='GT')
        plt.plot(x, y_pred[:, i], color='orange', label='pred')
        plt.legend()
        plt.xticks([])
        plt.yticks([])
        plt.title(f'day{i+1}')
    plt.savefig(f'{data_name}_{feature_selection.__name__}_{feature_normalization.__name__}.png')


if __name__ == "__main__":
    param_grid = {
        'hidden_layer_sizes': [(50, 50)],
        'max_iter': range(50, 200, 10),
        'activation': ['relu', 'tanh'],
        'solver': ['adam', 'sgd'],
        'learning_rate': ['constant', 'adaptive']
    }
    for data in {'01013500', '01047000', '01169000'}:
        for feature_selection in {pearson, mutualInformation}:
            for feature_norm in {minMaxNorm, zSocre}:
                neural_networks(data, feature_selection, feature_norm)
