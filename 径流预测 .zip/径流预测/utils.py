import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.pyplot as plt


def create_dataset(data, norm_data, input_days, output_days):
    X, y = [], []
    for i in range(len(data) - input_days - output_days + 1):
        X.append(norm_data.iloc[i+input_days-1].to_numpy())
        y.append(data.iloc[i+input_days:i+input_days+output_days]['Discharge_t_0'].to_numpy())
    return np.array(X), np.array(y)

def create_dataset_LSTM(data, norm_data, input_days, output_days, y_is_norm=True):
    X, y = [], []
    for i in range(len(data) - input_days - output_days + 1):
        df = pd.DataFrame(0, index=range(input_days+output_days), columns=['Discharge','Dayl','Prcp','Srad','Swe','Tmax','Tmin','Vp'], dtype=float)
        for feature in norm_data.columns:
            df.loc[input_days-int(feature.split('_')[-1])-1 if not (feature.split('_')[-1] == 'next') else input_days, feature.split('_')[0]] = norm_data.loc[i+input_days-1,feature]
        X.append(df)
        if y_is_norm:
            y.append(norm_data.iloc[i+input_days:i+input_days+output_days]['Discharge_t_0'].to_numpy())
        else:
            y.append(data.iloc[i+input_days:i+input_days+output_days]['Discharge_t_0'].to_numpy())
    return np.array(X), np.array(y)

def selectAndNorm(train_data, test_data, select_fc, norm_fc, feature_num):
    feature = select_fc(train_data, feature_num)
    train_data = train_data[feature]
    test_data = test_data[feature]
    train_data, test_data, scaler = norm_fc(train_data, test_data)
    return train_data, test_data, scaler

def evaluation(y_pred, y_true):
    for i in range(5):
        mae = mean_absolute_error(y_true[:,i], y_pred[:,i])
        r2 = r2_score(y_true[:,i], y_pred[:,i])
        variance = np.var(y_true[:, i])
        smse = mean_absolute_error(y_true[:, i],y_pred[:, i]) / variance if variance != 0 else np.nan # 计算SMSE，避免除零错误
        print(f' Day {i + 1}  R²: {r2}, MAE: {mae}, SMSE: {smse}')

def visualization(y_pred, y_true):
    x = [i for i in range(len(y_pred))]
    plt.figure(figsize=(10, 6))
    for i in range(5):
        plt.subplot(3, 2, i+1)
        plt.plot(x, y_true[:, i], color='blue', label='GT')
        plt.plot(x, y_pred[:, i], color='orange', label='pred')
        plt.legend()
        plt.xticks([])
        plt.yticks([])
        plt.title(f'day{i+1}')
    plt.show()

if __name__ == "__main__":
    pass