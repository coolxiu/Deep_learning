import pandas as pd
import warnings
warnings.filterwarnings("ignore", category=pd.errors.SettingWithCopyWarning)

def addNextPrcpAndDischarge(data, time):
    data_ = pd.DataFrame()
    for data_name in data.columns:
        if data_name != "Date":    
            data_.loc[:, f'{data_name}_next'] = data[data_name].shift(-1)
            for i in range(time):
                data_.loc[:, f'{data_name}_t_{i}'] = data[data_name].shift(i)
                # data.loc[:, f'{data_name}_t_1'] = data[data_name].shift(1)
                # data.loc[:, f'{data_name}_t_2'] = data[data_name].shift(2)
                # data.loc[:, f'{data_name}_t_3'] = data[data_name].shift(3)
                # data.loc[:, f'{data_name}_t_4'] = data[data_name].shift(4)
        else:
            data_.loc[:, 'Date'] = data[data_name]

    data_.fillna(0, inplace=True)
    
    return data_
    
if __name__ == "__main__":
    data = pd.read_csv('01013500.csv')
    data_ = addNextPrcpAndDischarge(data, 5)
    print(data_.head())