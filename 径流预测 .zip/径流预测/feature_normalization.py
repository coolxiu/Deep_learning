import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler

def minMaxNorm(train_data, test_data):
    scaler = MinMaxScaler()
    train_data = pd.DataFrame(scaler.fit_transform(train_data), columns=train_data.columns)
    test_data = pd.DataFrame(scaler.transform(test_data), columns=train_data.columns)
    return train_data, test_data, scaler

def zSocre(train_data, test_data):
    scaler = StandardScaler()
    train_data = pd.DataFrame(scaler.fit_transform(train_data), columns=train_data.columns)
    test_data = pd.DataFrame(scaler.transform(test_data), columns=train_data.columns)
    return train_data, test_data, scaler

if __name__ == "__main__":
    data = pd.read_csv('01169000.csv')
    train_data = data.where(data['Date'] <= '2003-12-31').dropna().drop(columns='Date')
    test_data = data.where(data['Date'] > '2003-12-31').dropna().drop(columns='Date')
    # train_data_norm, test_data_norm, _ = minMaxNorm(train_data, test_data)
    train_data_norm, test_data_norm, _ = zSocre(train_data, test_data)
    print(train_data_norm.head())
    print(test_data_norm.head())




