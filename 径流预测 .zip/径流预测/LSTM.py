import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
from add_next_prcp import addNextPrcpAndDischarge
from feature_normalization import minMaxNorm, zSocre
from feature_selection import pearson, mutualInformation
from utils import selectAndNorm
import warnings
from sklearn.exceptions import ConvergenceWarning
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from utils import create_dataset_LSTM, evaluation, visualization

# 定义 LSTM 模型类
class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(LSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.output_size = output_size
        # 定义 LSTM 层
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        # 定义全连接层
        self.fc = nn.Linear(hidden_size*output_size, output_size)


    
    def forward(self, x):
        B, L, D = x.shape
        # 初始化隐藏层状态和细胞状态
        # h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)  # hidden state
        # c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)  # cell state
        
        # LSTM 前向传播
        out, (h_n, c_n) = self.lstm(x)  # out: [batch_size, seq_length, hidden_size]

        # 只取最后一个时间步的输出
        output = self.fc(out[:, -5:, :].reshape(B, -1))

        return output


class myDataset(Dataset):
    def __init__(self,datas, labels):
        self.datas = datas
        self.labels = labels

    def __len__(self):
        return len(self.datas)
    
    def __getitem__(self, index):
        smaple = torch.from_numpy(self.datas[index]).float()
        label = torch.from_numpy(self.labels[index]).float()
        return smaple, label



class UseLSTM():
    def __init__(self, data_name, feature_selection, feature_normalization):
            time = 7
            feature_num = 30

            self.data_name = data_name
            self.feature_selection = feature_selection
            self.feature_normalization = feature_normalization

            df = pd.read_csv(f'{data_name}.csv')
            data = addNextPrcpAndDischarge(df, time)
            train_data = data.where(data['Date'] <= '2003-12-31').dropna()
            test_data = data.where(data['Date'] > '2003-12-31').dropna()
            train_norm_data, test_norm_data, scaler = selectAndNorm(train_data, test_data, feature_selection, feature_normalization, feature_num)

            x_train, y_train = create_dataset_LSTM(train_data, train_norm_data, time, 5, y_is_norm=True)
            x_test, y_test = create_dataset_LSTM(test_data, test_norm_data, time, 5, y_is_norm=False)
            train_data = myDataset(x_train, y_train)
            test_data = myDataset(x_test, y_test)

            self.train_dataloader = DataLoader(train_data, batch_size=32, shuffle=True)
            self.test_dataloader = DataLoader(test_data, batch_size=1, shuffle=False)

            self.y_true = y_test
            self.scaler = scaler

    def LSTM_train(self):
        model = LSTMModel(8, 10, 1, 5).to('cuda')

        loss_fn = nn.MSELoss()

        learning_rate = 1e-3
        optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, betas=(0.9, 0.999), eps=1e-08, weight_decay=0)
        # scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=100, gamma=0.1)

        epoch = 200
        total_train_step = 0
        total_val_step = 0
        best_val_loss = np.inf
        for i in range(epoch):
            print(f'-------第{i+1}轮训练开始---------')

            model.train()
            for data in self.train_dataloader:
                imgs, labels = data[0], data[1]
                imgs = imgs.to('cuda')
                labels = labels.to('cuda')
                outputs = model(imgs)
                loss = loss_fn(outputs, labels)

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                total_train_step += 1
                if total_train_step % 25 == 0:
                    print(f"训练次数：{total_train_step}，Loss：{loss.item()}")

            model.eval()
            total_val_loss = 0

            with torch.no_grad():
                for data in self.test_dataloader:
                    imgs, labels = data[0], data[1]
                    imgs = imgs.to('cuda')
                    labels = labels.to('cuda')
                    outputs = model(imgs)
                    loss = loss_fn(outputs, labels)
                    total_val_loss += loss.item()

            print(f"验证集上的Loss：{total_val_loss}")
            total_val_step += 1

            # if (i+1)%100 == 0:
            #     torch.save(model.state_dict(), f"model_save/LSTM_{i+1}_{self.data_name}_{self.feature_selection.__name__}_{self.feature_normalization.__name__}.pth")
            #     print("模型已保存")

            if best_val_loss > total_val_loss:
                best_val_loss = total_val_loss
                torch.save(model.state_dict(), f"model_save/best_LSTM_{self.data_name}_{self.feature_selection.__name__}_{self.feature_normalization.__name__}.pth")
                print("最好模型已更新\n\n")

    def LSTM_test(self, model_path):
        model = LSTMModel(8, 10, 1, 5)
        model.load_state_dict(torch.load(f'{model_path}', map_location='cpu'))

        model.eval()
        y_pred = []
        with torch.no_grad():
            for data in self.test_dataloader:
                imgs, labels = data[0], data[1]
                imgs = imgs
                labels = labels
                outputs = model(imgs)
                output = np.zeros((5, 30))
                output[:, 0] = outputs.numpy()
                output = self.scaler.inverse_transform(output)
                output = output[:, 0]
                y_pred.append(output)
        y_pred = np.squeeze(np.array(y_pred))
        evaluation(y_pred, self.y_true)

        x = [i for i in range(len(y_pred))]
        plt.figure(figsize=(10, 6))
        for i in range(5):
            plt.subplot(3, 2, i+1)
            plt.plot(x, self.y_true[:, i], color='blue', label='GT')
            plt.plot(x, y_pred[:, i], color='orange', label='pred')
            plt.legend()
            plt.xticks([])
            plt.yticks([])
            plt.title(f'day{i+1}')
        plt.savefig(f'image/{self.data_name}_{self.feature_selection.__name__}_{self.feature_normalization.__name__}.png')




if __name__ == "__main__":
    for data in {'01013500', '01047000', '01169000'}:
        for feature_selection in {pearson, mutualInformation}:
            for feature_norm in {zSocre, minMaxNorm}:
                print(f'\n\n{data}_{feature_selection.__name__}_{feature_norm.__name__}')
                useLstm = UseLSTM(data, feature_selection, feature_norm)
                # useLstm.LSTM_train()
                useLstm.LSTM_test(f'model_save/best_LSTM_{data}_{feature_selection.__name__}_{feature_norm.__name__}.pth')



